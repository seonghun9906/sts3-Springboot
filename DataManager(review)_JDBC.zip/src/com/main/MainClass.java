package com.main;

import com.controller.DataController;

public class MainClass {

	public static void main(String[] args) {
		DataController dc = new DataController();
		dc.controll();
	}

}
